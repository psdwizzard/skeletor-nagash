# Skeletor Nagash — voice replacement mod (TWW3)

Replaces Nagash's English voice lines (330 clips) in Total War: WARHAMMER III with a
voice-cloned classic-80s Skeletor. Built against game Update 9.0 ("Lords of the End
Times"). Personal-use mod.

## What's in here
- `skeletor_nagash.pack` — the mod. Contains only replacement `.wem` audio files at
  vanilla paths (`audio/wwise/english(uk)/<id>.wem`). No game file is modified.

## Install — macOS (Steam / Feral port)
1. Copy `skeletor_nagash.pack` into:
   `~/Library/Application Support/Steam/steamapps/common/Total War WARHAMMER III/TotalWarhammer3Data/data/`
2. Launch the game. The pack is Movie-type, so it loads automatically — no mod
   manager step needed.

## Install — Windows
1. Copy `skeletor_nagash.pack` into:
   `C:\Program Files (x86)\Steam\steamapps\common\Total War WARHAMMER III\data\`
2. Movie-type packs load automatically. (If you use a mod manager, it may also show up
   there; no enabling required.)

## Uninstall / rollback
Delete `skeletor_nagash.pack` from the data folder. That's it — the vanilla voice
returns. Originals are never touched by this mod. (Belt-and-braces: the project repo
keeps the extracted vanilla wems in `work/original_wem/`.)

## After game updates
Patches may ship new packs but won't remove this file. If a patch adds NEW Nagash
lines, those will play with his vanilla voice until the mod is regenerated. If audio
stops working after a major update, re-check that the file is still in `data/`.

## Known quirks
- Subtitles show the original line text; the spoken wording matches it, but pacing is
  snappier than the subtitle timing assumes.
- English VO only (other language audio untouched).
- Do not redistribute: the voice is cloned from a real actor's performance of a
  trademarked character.
